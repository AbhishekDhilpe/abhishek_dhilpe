/*
ASSIGNMENT NO:01
TITLE:create a class named weather report that hold daily weather report with data member ,day of month,
hightemp,lowtemp,amount rain &amount snow.use different types of constructor to initialize the object.
also include a function that prompt the user and set value for each field so that u can overide the default.
write a menudriven program in c++ with option to enter data and generate monthly report that display average of each attribute.
NAME:BHUSHAN BISANE
ROLL NO.12
BATCH:S1
IT(SE).
-----------------------------------------------
*/
#include <iostream>
using namespace std;
class wheather_report
{
public:
int dateofmonth,avg,hightemp,lowtemp,amount_rain,amount_snow;
wheather_report()
    {
dateofmonth=99;
hightemp=999;
lowtemp=-999;
amount_snow=0;
amount_rain=0;
    }
    void accept(int);
    void display_data();
    void average(wheather_report *t);
};

void wheather_report::accept(int d)                            //accept data
{
	dateofmonth=d;
	cout<<"\nEnter High temperature : ";
	cin>>hightemp;
	cout<<"\nEnter Low temperature : ";
	cin>>lowtemp;
	cout<<"\nEnter amount of rain : ";
	cin>>amount_rain;
	cout<<"\nEnter amount of snow : ";
	cin>>amount_snow;
}

void wheather_report::display_data()                           //display data
{
    cout<<"\t"<<dateofmonth<<"\t\t"<<hightemp<<"\t\t"<<lowtemp<<"\t\t"
<<amount_rain<<"\t\t"<<amount_snow<<"\n";
}

void wheather_report::average(wheather_report w[31])            //average
{
	int sumhightemp=0,sumlowtemp=0,sumrain=0,sumsnow=0,count=0;
int avg_htemp=0,avg_ltemp=0,avg_rain=0,avg_snow=0;
	for(int i=1;i<=31;i++)
	{
		if(w[i].dateofmonth!=99)                          //sum
		{
			sumhightemp= sumhightemp + w[i].hightemp;
			sumlowtemp= sumlowtemp + w[i].lowtemp;
			sumrain= sumrain + w[i].amount_rain;
			sumsnow= sumsnow + w[i].amount_snow;
			count++;
		}
	}
	avg_htemp=sumhightemp/count;
	avg_ltemp=sumlowtemp/count;
	avg_rain=sumrain/count;
	avg_snow=sumsnow/count;
	cout<<"\n Average of high temp is : "<<avg_htemp;
	cout<<"\n Average of low temp is : "<<avg_ltemp;
	cout<<"\n Average of total rain : "<<avg_rain;
	cout<<"\n Average of total snow : "<<avg_snow;
	}
int main()
{
wheather_report w[32],obj;
int day,ch,i,count=0;
do
    {
cout<<"\n***** MENU For Whether Report Program ****";
cout<<"\n1.Accept  data";
cout<<"\n2.Display data";
cout<<"\n3.Average Value";
cout<<"\n Enter your choice :  ";
cin>>ch;
        switch(ch)
        {
  case 1:cout<<"\nEnter date of month : ";
		cin>>day;
	    w[day].accept(day);     //accept data
	    count++;
                break;
  case 2: cout<<"\nDay\tDOM \t High_temp \t Low_temp \t  Amt_rain\t Amt_snow\n";
                for(i=1;i<=31;i++)
                {
	cout<<i;
                    w[i].display_data();    //display data
                }
                break;
   case 3:obj.average(w);             //average
	    break;
        }
}while(ch!=4);
    return 0;
}
/*  OUTPUT :
***** MENU For Whether Report Program ****
1.Accept  data
2.Display data
3.Average Value
 Enter your choice :  1

Enter date of month : 5

Enter High temperature : 25

Enter Low temperature : 36

Enter amount of rain : 98

Enter amount of snow : 41

***** MENU For Whether Report Program ****
1.Accept  data
2.Display data
3.Average Value
 Enter your choice :  1

Enter date of month : 85

Enter High temperature : 98

Enter Low temperature : 78

Enter amount of rain : 47

Enter amount of snow : 56

***** MENU For Whether Report Program ****
1.Accept  data
2.Display data
3.Average Value
 Enter your choice :  2

Day	DOM 	High_temp	Low_temp	Amt_rain	Amt_snow
1	99		999		-999		0		0
2	99		999		-999		0		0
3	99		999		-999		0		0
4	99		999		-999		0		0
5	5		25		36		98		41
6	99		999		-999		0		0
7	99		999		-999		0		0
8	99		999		-999		0		0
9	99		999		-999		0		0
10	99		999		-999		0		0
11	99		999		-999		0		0
12	99		999		-999		0		0
13	99		999		-999		0		0
14	99		999		-999		0		0
15	99		999		-999		0		0
16	99		999		-999		0		0
17	99		999		-999		0		0
18	99		999		-999		0		0
19	99		999		-999		0		0
20	99		999		-999		0		0
21	99		999		-999		0		0
22	99		999		-999		0		0
23	99		999		-999		0		0
24	99		999		-999		0		0
25	99		999		-999		0		0
26	99		999		-999		0		0
27	99		999		-999		0		0
28	99		999		-999		0		0
29	99		999		-999		0		0
30	99		999		-999		0		0
31	99		999		-999		0		0

***** MENU For Whether Report Program ****
1.Accept  data
2.Display data
3.Average Value
 Enter your choice :  3

 Average of high temp is : 25
 Average of low temp is : 36
 Average of total rain : 98
 Average of total snow : 41
***** MENU For Whether Report Program ****
1.Accept  data
2.Display data
3.Average Value
 Enter your choice :  4
*/
